#! /bin/sh

ROOT_PATH=`pwd`
BPCODER_PATH='/bpcoder'

PCRE_NAME=pcre-8.33
ZLIB_NAME=zlib-1.2.8
OPENSSL_NAME=openssl-1.0.1i
NGINX_NAME=nginx-1.6.2

if [ ! -d $ROOT_PATH/tmp ] ;then
	mkdir $ROOT_PATH/tmp
fi

if [ ! -d $BPCODER_PATH ] ;then
	mkdir $BPCODER_PATH
fi

##########      nginx      ##########
echo "============================Install Nginx================================="
if [ ! -d $BPCODER_PATH/nginx ] ;then
	groupadd www
	useradd -s /sbin/nologin -g www www
	tar zxf $ROOT_PATH/src/$PCRE_NAME.tar.gz -C $ROOT_PATH/tmp
	tar zxf $ROOT_PATH/src/$ZLIB_NAME.tar.gz -C $ROOT_PATH/tmp
	tar zxf $ROOT_PATH/src/$OPENSSL_NAME.tar.gz -C $ROOT_PATH/tmp
	tar zxf $ROOT_PATH/src/$NGINX_NAME.tar.gz -C $ROOT_PATH/tmp
	cd $ROOT_PATH/tmp/$NGINX_NAME
	./configure --user=www --group=www --prefix=$BPCODER_PATH/nginx --with-pcre=$ROOT_PATH/tmp/$PCRE_NAME --with-zlib=$ROOT_PATH/tmp/$ZLIB_NAME --with-openssl=$ROOT_PATH/tmp/$OPENSSL_NAME
	make && make install
	cp $ROOT_PATH/conf/nginx/nginx.conf $BPCODER_PATH/nginx/conf/nginx.conf
fi
echo "============================Nginx Success================================="
